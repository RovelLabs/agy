/**
 * OPERON Official Commercial Website & Edge Application
 * Cloudflare Worker / Edge Runtime Distribution
 * Compatible with Worker 'yellow-water-78f7' and Cloudflare Pages
 */

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;

    // API Routes
    if (path === '/api/health') {
      return new Response(JSON.stringify({
        status: 'healthy',
        product: 'OPERON',
        version: env.VERSION || '1.0.0-rc.1',
        environment: env.ENVIRONMENT || 'production',
        timestamp: new Date().toISOString()
      }), {
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (path === '/api/version') {
      return new Response(JSON.stringify({
        version: '1.0.0-rc.2',
        channel: 'release-candidate',
        releaseDate: '2026-09-14',
        downloads: {
          windows: { filename: 'OPERON-Windows-Installer-v1.0.0.zip', status: 'available', sizeBytes: 34461459 },
          macos: { filename: 'OPERON-macOS-Universal-v1.0.0.tar.gz', status: 'available', sizeBytes: 60825 },
          android: { filename: 'Operon-1.0.0.apk', status: 'available' },
          ios: { status: 'testflight-ready' }
        }
      }), {
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (path === '/robots.txt') {
      return new Response("User-agent: *\nAllow: /\nSitemap: https://operon.dev/sitemap.xml", {
        headers: { 'Content-Type': 'text/plain' }
      });
    }

    if (path === '/sitemap.xml') {
      return new Response(`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://operon.dev/</loc><changefreq>weekly</changefreq><priority>1.0</priority></url>
  <url><loc>https://operon.dev/#downloads</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>
  <url><loc>https://operon.dev/#pricing</loc><changefreq>monthly</changefreq><priority>0.8</priority></url>
</urlset>`, {
        headers: { 'Content-Type': 'application/xml' }
      });
    }

    // Serve Complete Production HTML Application
    const html = renderFullWebsite();
    return new Response(html, {
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'public, max-age=300, s-maxage=3600',
        'X-Content-Type-Options': 'nosniff',
        'X-Frame-Options': 'DENY',
        'Referrer-Policy': 'strict-origin-when-cross-origin'
      }
    });
  }
};

export function renderFullWebsite() {
  return `<!DOCTYPE html>
<html lang="en" data-theme="graphite" data-lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OPERON — The Autonomous Personal Operating Layer</title>
  <meta name="description" content="Sub-millisecond personal automation for Windows, macOS, Android, and iOS. 100% local-first, zero mandatory cloud, deterministic DAG engine.">
  <meta property="og:title" content="OPERON — The Autonomous Personal Operating Layer">
  <meta property="og:description" content="Eliminate repetitive digital work across text, files, clipboard, and apps. Sub-millisecond execution, zero cloud accounts required.">
  <meta property="og:type" content="website">
  <meta name="twitter:card" content="summary_large_image">
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><polygon points='16,2 29,9.5 29,22.5 16,30 3,22.5 3,9.5' fill='%23121518' stroke='%2338BDF8' stroke-width='2.5'/><circle cx='16' cy='16' r='3.5' fill='%2338BDF8'/></svg>">
  <style>
    :root {
      --font-sans: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI Variable Text", Roboto, sans-serif;
      --font-mono: "JetBrains Mono", "Cascadia Code", monospace;
    }

    /* THEMES */
    [data-theme="graphite"] {
      --bg-0: #0a0c0e;
      --bg-1: #121518;
      --bg-2: #1a1e22;
      --bg-3: #24292e;
      --border-faint: rgba(255, 255, 255, 0.06);
      --border-subtle: rgba(255, 255, 255, 0.12);
      --border-focus: #38bdf8;
      --text-1: #f1f5f9;
      --text-2: #94a3b8;
      --text-3: #64748b;
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.18);
      --success: #34d399;
      --warning: #fbbf24;
      --danger: #f87171;
    }

    [data-theme="midnight"] {
      --bg-0: #080c14;
      --bg-1: #0e1522;
      --bg-2: #162032;
      --bg-3: #1f2b42;
      --border-faint: rgba(148, 163, 184, 0.08);
      --border-subtle: rgba(148, 163, 184, 0.16);
      --border-focus: #60a5fa;
      --text-1: #f8fafc;
      --text-2: #94a3b8;
      --text-3: #64748b;
      --accent: #60a5fa;
      --accent-glow: rgba(96, 165, 250, 0.2);
      --success: #34d399;
      --warning: #fbbf24;
      --danger: #f87171;
    }

    [data-theme="oled"] {
      --bg-0: #000000;
      --bg-1: #0a0a0a;
      --bg-2: #141414;
      --bg-3: #1e1e1e;
      --border-faint: rgba(255, 255, 255, 0.10);
      --border-subtle: rgba(255, 255, 255, 0.20);
      --border-focus: #38bdf8;
      --text-1: #ffffff;
      --text-2: #a3a3a3;
      --text-3: #737373;
      --accent: #38bdf8;
      --accent-glow: rgba(56, 189, 248, 0.25);
      --success: #34d399;
      --warning: #fbbf24;
      --danger: #f87171;
    }

    [data-theme="lunar"] {
      --bg-0: #f8fafc;
      --bg-1: #ffffff;
      --bg-2: #f1f5f9;
      --bg-3: #e2e8f0;
      --border-faint: rgba(0, 0, 0, 0.06);
      --border-subtle: rgba(0, 0, 0, 0.14);
      --border-focus: #0284c7;
      --text-1: #0f172a;
      --text-2: #475569;
      --text-3: #94a3b8;
      --accent: #0284c7;
      --accent-glow: rgba(2, 132, 199, 0.15);
      --success: #10b981;
      --warning: #f59e0b;
      --danger: #ef4444;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }
    html { scroll-behavior: smooth; }
    body {
      background-color: var(--bg-0);
      color: var(--text-1);
      font-family: var(--font-sans);
      font-size: 14px;
      line-height: 1.6;
      -webkit-font-smoothing: antialiased;
      transition: background-color 200ms ease, color 200ms ease;
    }

    .container {
      max-width: 1140px;
      margin: 0 auto;
      padding: 0 24px;
    }

    /* NAVBAR */
    .nav {
      position: sticky;
      top: 0;
      background: var(--bg-0);
      background: color-mix(in srgb, var(--bg-0) 85%, transparent);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border-bottom: 1px solid var(--border-faint);
      z-index: 1000;
      padding: 14px 0;
      transition: background-color 200ms ease;
    }
    .nav-inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .nav-brand {
      display: flex;
      align-items: center;
      gap: 10px;
      font-family: var(--font-mono);
      font-weight: 700;
      font-size: 16px;
      color: var(--text-1);
      text-decoration: none;
      letter-spacing: 0.06em;
    }
    .nav-brand svg { width: 26px; height: 26px; }
    .nav-links {
      display: flex;
      align-items: center;
      gap: 22px;
    }
    .nav-link {
      color: var(--text-2);
      text-decoration: none;
      font-size: 13px;
      font-weight: 500;
      transition: color 140ms ease;
    }
    .nav-link:hover { color: var(--text-1); }
    .nav-controls {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .btn-chip {
      background: var(--bg-2);
      border: 1px solid var(--border-subtle);
      color: var(--text-1);
      font-family: var(--font-mono);
      font-size: 11px;
      padding: 5px 9px;
      border-radius: 6px;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: all 120ms ease;
    }
    .btn-chip:hover { border-color: var(--accent); color: var(--accent); }
    .nav-cta {
      background: var(--accent);
      color: #000;
      padding: 7px 16px;
      border-radius: 6px;
      font-weight: 600;
      font-size: 12px;
      text-decoration: none;
      transition: transform 100ms ease, box-shadow 100ms ease;
    }
    .nav-cta:hover { transform: translateY(-1px); box-shadow: 0 0 16px var(--accent-glow); }

    /* HERO */
    .hero {
      text-align: center;
      padding: 72px 0 36px;
    }
    .hero-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 5px 14px;
      border-radius: 999px;
      background: var(--bg-2);
      border: 1px solid var(--border-subtle);
      font-family: var(--font-mono);
      font-size: 11px;
      color: var(--accent);
      margin-bottom: 24px;
    }
    .hero-title {
      font-size: 52px;
      font-weight: 700;
      letter-spacing: -0.035em;
      line-height: 1.12;
      margin-bottom: 22px;
      max-width: 860px;
      margin-left: auto;
      margin-right: auto;
    }
    .hero-subtitle {
      font-size: 18px;
      color: var(--text-2);
      max-width: 720px;
      margin: 0 auto 36px;
      line-height: 1.55;
    }
    .hero-actions {
      display: flex;
      justify-content: center;
      gap: 14px;
      flex-wrap: wrap;
      margin-bottom: 48px;
    }
    .btn-lg {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 13px 26px;
      border-radius: 8px;
      font-weight: 600;
      font-size: 14px;
      text-decoration: none;
      transition: transform 120ms ease, box-shadow 120ms ease;
    }
    .btn-primary {
      background: var(--accent);
      color: #000;
      box-shadow: 0 0 24px var(--accent-glow);
    }
    .btn-primary:hover { transform: translateY(-2px); }
    .btn-secondary {
      background: var(--bg-1);
      color: var(--text-1);
      border: 1px solid var(--border-subtle);
    }
    .btn-secondary:hover { background: var(--bg-2); }

    /* INTERACTIVE HERO HUD SHOWCASE */
    .hero-hud-frame {
      max-width: 760px;
      margin: 0 auto 72px;
      background: var(--bg-1);
      border: 1px solid var(--border-subtle);
      border-radius: 16px;
      box-shadow: 0 24px 72px -12px rgba(0, 0, 0, 0.8), 0 0 0 1px rgba(255, 255, 255, 0.05);
      overflow: hidden;
      text-align: left;
    }
    .hud-titlebar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 18px;
      background: var(--bg-0);
      border-bottom: 1px solid var(--border-faint);
    }
    .hud-dots { display: flex; gap: 7px; }
    .hud-dot { width: 10px; height: 10px; border-radius: 50%; }
    .hud-header-info {
      font-family: var(--font-mono);
      font-size: 11px;
      color: var(--text-3);
    }
    .hud-body { padding: 20px 24px; }
    .hud-input-row {
      display: flex;
      align-items: center;
      gap: 12px;
      background: var(--bg-2);
      border: 1px solid var(--border-subtle);
      border-radius: 10px;
      padding: 12px 16px;
      margin-bottom: 16px;
    }
    .hud-input-row svg { width: 18px; height: 18px; color: var(--accent); flex-shrink: 0; }
    .hud-input {
      flex: 1;
      background: transparent;
      border: none;
      outline: none;
      font-family: var(--font-sans);
      font-size: 14px;
      color: var(--text-1);
    }
    .hud-input::placeholder { color: var(--text-3); }
    .hud-presets {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin-bottom: 18px;
    }
    .hud-preset-chip {
      background: var(--bg-2);
      border: 1px solid var(--border-faint);
      color: var(--text-2);
      font-size: 11px;
      font-weight: 500;
      padding: 5px 12px;
      border-radius: 6px;
      cursor: pointer;
      transition: all 120ms ease;
    }
    .hud-preset-chip:hover, .hud-preset-chip.active {
      border-color: var(--accent);
      color: var(--accent);
      background: var(--bg-3);
    }
    .hud-execution-view {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      background: var(--bg-0);
      border: 1px solid var(--border-faint);
      border-radius: 10px;
      padding: 16px;
    }
    .exec-col-label {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--text-3);
      margin-bottom: 8px;
      display: flex;
      justify-content: space-between;
    }
    .exec-content-box {
      font-family: var(--font-mono);
      font-size: 11.5px;
      color: var(--text-2);
      white-space: pre-wrap;
      max-height: 150px;
      overflow-y: auto;
      line-height: 1.5;
    }
    .exec-content-box.out { color: var(--success); }
    .hud-footer-metrics {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-top: 14px;
      font-size: 11px;
      color: var(--text-3);
      font-family: var(--font-mono);
    }
    .metric-pill { color: var(--accent); font-weight: 600; }

    /* SECTION BASICS */
    section { padding: 64px 0; }
    .section-header {
      text-align: center;
      max-width: 680px;
      margin: 0 auto 48px;
    }
    .section-tag {
      font-family: var(--font-mono);
      font-size: 11px;
      font-weight: 600;
      color: var(--accent);
      text-transform: uppercase;
      letter-spacing: 0.08em;
      margin-bottom: 8px;
    }
    .section-title {
      font-size: 34px;
      font-weight: 700;
      letter-spacing: -0.025em;
      margin-bottom: 14px;
    }
    .section-subtitle {
      color: var(--text-2);
      font-size: 15px;
      line-height: 1.6;
    }

    /* BEFORE / AFTER CARDS */
    .diff-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 24px;
    }
    .diff-card {
      background: var(--bg-1);
      border: 1px solid var(--border-faint);
      border-radius: 14px;
      padding: 24px;
      transition: border-color 140ms ease;
    }
    .diff-card:hover { border-color: var(--border-subtle); }
    .diff-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
    }
    .diff-badge-before {
      background: rgba(248, 113, 113, 0.12);
      color: var(--danger);
      font-family: var(--font-mono);
      font-size: 10px;
      font-weight: 700;
      padding: 3px 8px;
      border-radius: 4px;
    }
    .diff-badge-after {
      background: rgba(52, 211, 153, 0.12);
      color: var(--success);
      font-family: var(--font-mono);
      font-size: 10px;
      font-weight: 700;
      padding: 3px 8px;
      border-radius: 4px;
    }
    .diff-title { font-size: 16px; font-weight: 600; margin-bottom: 8px; }
    .diff-desc { font-size: 13px; color: var(--text-2); margin-bottom: 16px; line-height: 1.5; }
    .diff-stat {
      background: var(--bg-0);
      border-radius: 8px;
      padding: 12px;
      font-family: var(--font-mono);
      font-size: 12px;
      color: var(--accent);
      display: flex;
      justify-content: space-between;
    }

    /* RECIPE CATALOG */
    .recipes-catalog-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px;
    }
    .recipe-card {
      background: var(--bg-1);
      border: 1px solid var(--border-faint);
      border-radius: 10px;
      padding: 18px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      transition: all 120ms ease;
    }
    .recipe-card:hover {
      border-color: var(--border-subtle);
      transform: translateY(-2px);
    }
    .recipe-icon { font-size: 20px; margin-bottom: 10px; }
    .recipe-name { font-size: 14px; font-weight: 600; margin-bottom: 6px; }
    .recipe-detail { font-size: 12px; color: var(--text-2); margin-bottom: 12px; flex: 1; }
    .recipe-meta {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-family: var(--font-mono);
      font-size: 10px;
      color: var(--text-3);
    }

    /* PLATFORM MATRIX */
    .platforms-row {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 18px;
    }
    .platform-col {
      background: var(--bg-1);
      border: 1px solid var(--border-faint);
      border-radius: 12px;
      padding: 22px;
      text-align: center;
    }
    .platform-icon { font-size: 32px; margin-bottom: 12px; }
    .platform-title { font-size: 16px; font-weight: 600; margin-bottom: 4px; }
    .platform-spec { font-family: var(--font-mono); font-size: 11px; color: var(--accent); margin-bottom: 12px; }
    .platform-features { list-style: none; text-align: left; font-size: 12px; color: var(--text-2); display: flex; flex-direction: column; gap: 6px; }

    /* PERFORMANCE METRICS GRID */
    .perf-metrics-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
      text-align: center;
    }
    .perf-metric-card {
      background: var(--bg-1);
      border: 1px solid var(--border-faint);
      border-radius: 12px;
      padding: 28px 16px;
    }
    .metric-val {
      font-size: 38px;
      font-weight: 700;
      font-family: var(--font-mono);
      color: var(--accent);
      margin-bottom: 6px;
    }
    .metric-label { font-size: 13px; color: var(--text-2); font-weight: 500; }

    /* PRICING */
    .pricing-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 24px;
      max-width: 1040px;
      margin: 0 auto;
      text-align: left;
    }
    .pricing-card {
      background: var(--bg-1);
      border: 1px solid var(--border-faint);
      border-radius: 16px;
      padding: 32px;
      display: flex;
      flex-direction: column;
      position: relative;
    }
    .pricing-card.pro {
      border-color: var(--accent);
      box-shadow: 0 0 32px var(--accent-glow);
    }
    .pricing-card.lifetime {
      background: linear-gradient(180deg, var(--bg-1) 0%, var(--bg-2) 100%);
      border-color: var(--border-subtle);
    }
    .pricing-tier {
      font-family: var(--font-mono);
      font-size: 11px;
      color: var(--accent);
      text-transform: uppercase;
      letter-spacing: 0.08em;
      margin-bottom: 8px;
    }
    .pricing-price {
      font-size: 42px;
      font-weight: 700;
      margin: 8px 0 16px;
      font-family: var(--font-sans);
    }
    .pricing-price span {
      font-size: 13px;
      font-weight: 400;
      color: var(--text-2);
    }
    .pricing-features {
      list-style: none;
      margin: 20px 0;
      font-size: 13px;
      color: var(--text-2);
      display: flex;
      flex-direction: column;
      gap: 10px;
      flex: 1;
    }
    .pricing-features li { display: flex; gap: 8px; align-items: flex-start; }
    .check-icon { color: var(--accent); font-weight: 700; }

    /* FAQ ACCORDION */
    .faq-list {
      max-width: 780px;
      margin: 0 auto;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    .faq-item {
      background: var(--bg-1);
      border: 1px solid var(--border-faint);
      border-radius: 10px;
      overflow: hidden;
    }
    .faq-question {
      padding: 16px 20px;
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .faq-question:hover { color: var(--accent); }
    .faq-answer {
      padding: 0 20px 18px;
      color: var(--text-2);
      font-size: 13px;
      line-height: 1.6;
      display: none;
    }
    .faq-item.open .faq-answer { display: block; }
    .faq-item.open .faq-chevron { transform: rotate(180deg); }

    /* FOOTER */
    .footer {
      border-top: 1px solid var(--border-faint);
      padding: 60px 0 32px;
      margin-top: 64px;
      font-size: 13px;
      color: var(--text-2);
    }
    .footer-grid {
      display: grid;
      grid-template-columns: 2fr 1fr 1fr 1fr;
      gap: 40px;
      margin-bottom: 48px;
    }
    .footer-col-title {
      font-size: 13px;
      font-weight: 600;
      color: var(--text-1);
      margin-bottom: 14px;
    }
    .footer-links { list-style: none; display: flex; flex-direction: column; gap: 8px; }
    .footer-links a { color: var(--text-2); text-decoration: none; transition: color 100ms; }
    .footer-links a:hover { color: var(--text-1); }
    .footer-bottom {
      border-top: 1px solid var(--border-faint);
      padding-top: 24px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 12px;
      color: var(--text-3);
    }

    /* RESPONSIVENESS */
    @media (max-width: 960px) {
      .hero-title { font-size: 38px; }
      .diff-grid, .hud-execution-view, .pricing-grid { grid-template-columns: 1fr; }
      .recipes-catalog-grid { grid-template-columns: repeat(2, 1fr); }
      .platforms-row, .perf-metrics-grid { grid-template-columns: repeat(2, 1fr); }
      .footer-grid { grid-template-columns: 1fr 1fr; }
    }
    @media (max-width: 640px) {
      .hero-title { font-size: 30px; }
      .nav-links { display: none; }
      .recipes-catalog-grid, .platforms-row, .perf-metrics-grid, .footer-grid { grid-template-columns: 1fr; }
    }

    @media (prefers-reduced-motion: reduce) {
      * { animation-duration: 0.01ms !important; transition-duration: 0.01ms !important; }
    }
  </style>
</head>
<body>
  <!-- Top Glass Navigation -->
  <header class="nav">
    <div class="container nav-inner">
      <a href="/" class="nav-brand">
        <svg viewBox="0 0 32 32">
          <polygon points="16,2 29,9.5 29,22.5 16,30 3,22.5 3,9.5" fill="#121518" stroke="#38BDF8" stroke-width="2.5"/>
          <circle cx="16" cy="16" r="3.5" fill="#38BDF8"/>
        </svg>
        OPERON
      </a>
      <nav class="nav-links">
        <a href="#demo" class="nav-link" data-i18n="nav_demo">Interactive HUD</a>
        <a href="#before-after" class="nav-link" data-i18n="nav_diff">Before vs After</a>
        <a href="#recipes" class="nav-link" data-i18n="nav_recipes">15 Recipes</a>
        <a href="#platforms" class="nav-link" data-i18n="nav_platforms">Platforms</a>
        <a href="#pricing" class="nav-link" data-i18n="nav_pricing">Pricing</a>
        <a href="#faq" class="nav-link" data-i18n="nav_faq">FAQ</a>
      </nav>
      <div class="nav-controls">
        <button class="btn-chip" id="langSwitchBtn" title="Switch Language">
          <span id="currentLangLabel">EN</span> 🌐
        </button>
        <button class="btn-chip" id="themeSwitchBtn" title="Cycle Themes">
          <span id="currentThemeLabel">Graphite</span> ◐
        </button>
        <a href="#downloads" class="nav-cta" data-i18n="nav_get">Get Operon</a>
      </div>
    </div>
  </header>

  <!-- Hero Section -->
  <section class="hero">
    <div class="container">
      <div class="hero-badge">
        <span style="color:#34D399">●</span> <span data-i18n="hero_badge">RELEASE CANDIDATE 1.0 • SUB-1MS DETERMINISTIC CORE</span>
      </div>
      <h1 class="hero-title" data-i18n="hero_title">
        The Autonomous Personal Operating Layer
      </h1>
      <p class="hero-subtitle" data-i18n="hero_sub">
        Eliminate repetitive digital work across text, files, clipboard, and apps.
        Sub-millisecond keyboard HUD on desktop, fluid Share Sheet routines on mobile.
        100% local-first. Zero mandatory cloud accounts.
      </p>
      <div class="hero-actions">
        <a href="#downloads" class="btn-lg btn-primary" data-i18n="hero_btn_download">Download Free for Desktop & Mobile</a>
        <a href="#demo" class="btn-lg btn-secondary" data-i18n="hero_btn_demo">Try Interactive HUD Simulation</a>
      </div>

      <!-- Interactive Hero HUD Window -->
      <div class="hero-hud-frame" id="demo">
        <div class="hud-titlebar">
          <div class="hud-dots">
            <span class="hud-dot" style="background:#ff5f56"></span>
            <span class="hud-dot" style="background:#ffbd2e"></span>
            <span class="hud-dot" style="background:#27c93f"></span>
          </div>
          <span class="hud-header-info">Alt+Space • OPERON Quick Command Overlay</span>
          <span class="hud-header-info" style="color:var(--accent)">100% OFFLINE</span>
        </div>
        <div class="hud-body">
          <div class="hud-input-row">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
            <input type="text" id="interactiveHudInput" class="hud-input" placeholder="Type a command or click a routine below...">
            <span style="font-family:var(--font-mono); font-size:10px; color:var(--text-3); background:var(--bg-3); padding:2px 6px; border-radius:4px;">ENTER ↵</span>
          </div>

          <!-- Preset Routine Chips -->
          <div class="hud-presets">
            <button class="hud-preset-chip active" onclick="setPreset('clean_url')" data-i18n="preset_clean_url">Clean Tracking URL</button>
            <button class="hud-preset-chip" onclick="setPreset('format_json')" data-i18n="preset_format_json">Format & Indent JSON</button>
            <button class="hud-preset-chip" onclick="setPreset('tsv_md')" data-i18n="preset_tsv_md">CSV/TSV to Markdown Table</button>
            <button class="hud-preset-chip" onclick="setPreset('rename_files')" data-i18n="preset_rename_files">Batch Rename 50 Files</button>
            <button class="hud-preset-chip" onclick="setPreset('ai_intent')" data-i18n="preset_ai_intent">✨ Local AI Intent Compiler</button>
          </div>

          <div class="hud-execution-view">
            <div>
              <div class="exec-col-label">
                <span data-i18n="exec_input_label">Raw Input Data</span>
                <span id="inputSizeBadge">128 B</span>
              </div>
              <div class="exec-content-box" id="execInputBox">// Input payload</div>
            </div>
            <div>
              <div class="exec-col-label">
                <span data-i18n="exec_output_label">Deterministic Output</span>
                <span id="outputSpeedBadge" style="color:var(--accent)">0.076 ms</span>
              </div>
              <div class="exec-content-box out" id="execOutputBox">// Output result</div>
            </div>
          </div>

          <div class="hud-footer-metrics">
            <span><strong data-i18n="engine_mode">Engine Mode:</strong> <span class="metric-pill">Deterministic DAG</span></span>
            <span><strong data-i18n="memory_impact">RAM Impact:</strong> <span class="metric-pill">0.0 MB (Local)</span></span>
            <span><strong data-i18n="privacy_status">Privacy:</strong> <span style="color:#34D399">Encrypted Local-First</span></span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Before vs After Demonstrations -->
  <section id="before-after" style="background: var(--bg-1);">
    <div class="container">
      <div class="section-header">
        <div class="section-tag" data-i18n="diff_tag">REAL TIME SAVINGS</div>
        <h2 class="section-title" data-i18n="diff_title">Normally 12 clicks. Now 1 keystroke.</h2>
        <p class="section-subtitle" data-i18n="diff_sub">Operon bridges the gap between intention and execution across your operating system.</p>
      </div>
      <div class="diff-grid">
        <div class="diff-card">
          <div class="diff-header">
            <span class="diff-badge-before" data-i18n="diff_badge_old">THE OLD WAY: 14 MINUTES</span>
            <span style="font-size:12px; color:var(--text-3);">48 manual clicks</span>
          </div>
          <h3 class="diff-title" data-i18n="diff_1_title">Batch Renaming & Compressing 50 PNG Screenshots</h3>
          <p class="diff-desc" data-i18n="diff_1_desc">Opening Photoshop or an online converter, waiting for uploads, manually typing dates, and moving files one by one.</p>
          <div class="diff-stat">
            <span class="diff-badge-after" data-i18n="diff_badge_operon">WITH OPERON: 0.4 SECONDS</span>
            <span>Drag & Drop $\rightarrow$ 85% Space Saved</span>
          </div>
        </div>

        <div class="diff-card">
          <div class="diff-header">
            <span class="diff-badge-before" data-i18n="diff_badge_old">THE OLD WAY: 45 SECONDS</span>
            <span style="font-size:12px; color:var(--text-3);">Manual URL editing</span>
          </div>
          <h3 class="diff-title" data-i18n="diff_2_title">Stripping Tracking Spying from Shared Links</h3>
          <p class="diff-desc" data-i18n="diff_2_desc">Carefully highlighting and deleting utm_source, fbclid, and gclid tokens from messy links before sharing in chat.</p>
          <div class="diff-stat">
            <span class="diff-badge-after" data-i18n="diff_badge_operon">WITH OPERON: 10 MILLISECONDS</span>
            <span>Alt+Space $\rightarrow$ Enter $\rightarrow$ Cleaned</span>
          </div>
        </div>

        <div class="diff-card">
          <div class="diff-header">
            <span class="diff-badge-before" data-i18n="diff_badge_old">THE OLD WAY: 3 MINUTES</span>
            <span style="font-size:12px; color:var(--text-3);">Broken formatting</span>
          </div>
          <h3 class="diff-title" data-i18n="diff_3_title">Pasting Spreadsheet Data to Markdown</h3>
          <p class="diff-desc" data-i18n="diff_3_desc">Copying Excel or Google Sheets into GitHub or Notion results in unaligned tabs and broken text lines.</p>
          <div class="diff-stat">
            <span class="diff-badge-after" data-i18n="diff_badge_operon">WITH OPERON: INSTANT</span>
            <span>Tabular TSV $\rightarrow$ GitHub Markdown Table</span>
          </div>
        </div>

        <div class="diff-card">
          <div class="diff-header">
            <span class="diff-badge-before" data-i18n="diff_badge_old">THE OLD WAY: HIGH SECURITY RISK</span>
            <span style="font-size:12px; color:var(--text-3);">Public web converters</span>
          </div>
          <h3 class="diff-title" data-i18n="diff_4_title">Inspecting JWT Tokens & Formatting API JSON</h3>
          <p class="diff-desc" data-i18n="diff_4_desc">Pasting proprietary API payloads and authentication tokens into third-party online tools exposes private credentials.</p>
          <div class="diff-stat">
            <span class="diff-badge-after" data-i18n="diff_badge_operon">WITH OPERON: 100% PRIVATE</span>
            <span>Zero Network Calls $\rightarrow$ Offline Parse</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 15 Curated Production Recipes -->
  <section id="recipes">
    <div class="container">
      <div class="section-header">
        <div class="section-tag" data-i18n="recipes_tag">BUILT-IN PRODUCTION LIBRARY</div>
        <h2 class="section-title" data-i18n="recipes_title">15 Curated Recipes Ready on Day One</h2>
        <p class="section-subtitle" data-i18n="recipes_sub">No empty placeholders. Every single recipe is fully tested, typed, and executes instantly.</p>
      </div>

      <div class="recipes-catalog-grid">
        <div class="recipe-card">
          <div class="recipe-icon">🔗</div>
          <div class="recipe-name" data-i18n="r1_name">Strip Tracking Parameters</div>
          <div class="recipe-detail" data-i18n="r1_desc">Removes UTM, fbclid, gclid, and analytics tracking from copied URLs.</div>
          <div class="recipe-meta"><span>TEXT DOMAIN</span><span>0.04 ms</span></div>
        </div>
        <div class="recipe-card">
          <div class="recipe-icon">📋</div>
          <div class="recipe-name" data-i18n="r2_name">Format & Validate JSON</div>
          <div class="recipe-detail" data-i18n="r2_desc">Validates syntax and formats messy payloads with clean 2-space indentation.</div>
          <div class="recipe-meta"><span>DEV DOMAIN</span><span>0.08 ms</span></div>
        </div>
        <div class="recipe-card">
          <div class="recipe-icon">📊</div>
          <div class="recipe-name" data-i18n="r3_name">CSV/TSV to Markdown Table</div>
          <div class="recipe-detail" data-i18n="r3_desc">Parses tabular spreadsheet text and builds formatted GitHub Markdown tables.</div>
          <div class="recipe-meta"><span>TEXT DOMAIN</span><span>0.12 ms</span></div>
        </div>
        <div class="recipe-card">
          <div class="recipe-icon">📁</div>
          <div class="recipe-name" data-i18n="r4_name">Batch Rename with Timestamp</div>
          <div class="recipe-detail" data-i18n="r4_desc">Sequentially renames file batches with ISO dates and sequence counters.</div>
          <div class="recipe-meta"><span>FILE DOMAIN</span><span>0.30 ms</span></div>
        </div>
        <div class="recipe-card">
          <div class="recipe-icon">🖼️</div>
          <div class="recipe-name" data-i18n="r5_name">Compress Images to WebP</div>
          <div class="recipe-detail" data-i18n="r5_desc">Converts PNG and JPEG images to lightweight WebP at 85% quality.</div>
          <div class="recipe-meta"><span>IMAGE DOMAIN</span><span>Native</span></div>
        </div>
        <div class="recipe-card">
          <div class="recipe-icon">🛡️</div>
          <div class="recipe-name" data-i18n="r6_name">Strip EXIF & Geolocation</div>
          <div class="recipe-detail" data-i18n="r6_desc">Removes GPS coordinates, camera models, and private metadata from photos.</div>
          <div class="recipe-meta"><span>PRIVACY DOMAIN</span><span>Native</span></div>
        </div>
        <div class="recipe-card">
          <div class="recipe-icon">🔑</div>
          <div class="recipe-name" data-i18n="r7_name">Offline JWT Inspector</div>
          <div class="recipe-detail" data-i18n="r7_desc">Decodes token claims, headers, and expiration dates without network leaks.</div>
          <div class="recipe-meta"><span>DEV DOMAIN</span><span>0.05 ms</span></div>
        </div>
        <div class="recipe-card">
          <div class="recipe-icon">⚙️</div>
          <div class="recipe-name" data-i18n="r8_name">Base64 Encode Clipboard</div>
          <div class="recipe-detail" data-i18n="r8_desc">Encodes text directly into Base64 format with optional URL-safe encoding.</div>
          <div class="recipe-meta"><span>DEV DOMAIN</span><span>0.02 ms</span></div>
        </div>
        <div class="recipe-card">
          <div class="recipe-icon">🔓</div>
          <div class="recipe-name" data-i18n="r9_name">Base64 Decode to Plain Text</div>
          <div class="recipe-detail" data-i18n="r9_desc">Decodes Base64 strings back to clean UTF-8 readable text.</div>
          <div class="recipe-meta"><span>DEV DOMAIN</span><span>0.02 ms</span></div>
        </div>
        <div class="recipe-card">
          <div class="recipe-icon">#️⃣</div>
          <div class="recipe-name" data-i18n="r10_name">Calculate SHA-256 Checksum</div>
          <div class="recipe-detail" data-i18n="r10_desc">Generates cryptographic hexadecimal checksums for text or code blocks.</div>
          <div class="recipe-meta"><span>DEV DOMAIN</span><span>0.06 ms</span></div>
        </div>
        <div class="recipe-card">
          <div class="recipe-icon">🐫</div>
          <div class="recipe-name" data-i18n="r11_name">Convert to camelCase</div>
          <div class="recipe-detail" data-i18n="r11_desc">Transforms phrases into programming-standard camelCase identifiers.</div>
          <div class="recipe-meta"><span>TEXT DOMAIN</span><span>0.03 ms</span></div>
        </div>
        <div class="recipe-card">
          <div class="recipe-icon">🍢</div>
          <div class="recipe-name" data-i18n="r12_name">Convert to kebab-case</div>
          <div class="recipe-detail" data-i18n="r12_desc">Transforms text into clean URL slugs and CSS class identifiers.</div>
          <div class="recipe-meta"><span>TEXT DOMAIN</span><span>0.03 ms</span></div>
        </div>
        <div class="recipe-card">
          <div class="recipe-icon">🔎</div>
          <div class="recipe-name" data-i18n="r13_name">Extract All URLs from Text</div>
          <div class="recipe-detail" data-i18n="r13_desc">Scans messy notes and extracts a clean de-duplicated list of hyperlinks.</div>
          <div class="recipe-meta"><span>TEXT DOMAIN</span><span>0.05 ms</span></div>
        </div>
        <div class="recipe-card">
          <div class="recipe-icon">📝</div>
          <div class="recipe-name" data-i18n="r14_name">Local Text Summary</div>
          <div class="recipe-detail" data-i18n="r14_desc">Extracts key sentences and calculates reading time metrics 100% offline.</div>
          <div class="recipe-meta"><span>AI DOMAIN</span><span>0.90 ms</span></div>
        </div>
        <div class="recipe-card">
          <div class="recipe-icon">🔔</div>
          <div class="recipe-name" data-i18n="r15_name">System Notification Toast</div>
          <div class="recipe-detail" data-i18n="r15_desc">Dispatches native OS notification toasts with sub-millisecond execution.</div>
          <div class="recipe-meta"><span>SYSTEM DOMAIN</span><span>Native</span></div>
        </div>
      </div>
    </div>
  </section>

  <!-- Platform Honesty Matrix -->
  <section id="platforms" style="background: var(--bg-1);">
    <div class="container">
      <div class="section-header">
        <div class="section-tag" data-i18n="platforms_tag">HONEST ARCHITECTURE</div>
        <h2 class="section-title" data-i18n="platforms_title">Engineered Natively for Each OS</h2>
        <p class="section-subtitle" data-i18n="platforms_sub">We respect platform capabilities and security sandboxes. No fake background daemons where OS policies forbid it.</p>
      </div>

      <div class="platforms-row">
        <div class="platform-col">
          <div class="platform-icon">🪟</div>
          <div class="platform-title">Windows</div>
          <div class="platform-spec">Win 10/11 x64</div>
          <ul class="platform-features">
            <li>✓ Global Hotkey (Alt+Space)</li>
            <li>✓ Shell_NotifyIcon Tray</li>
            <li>✓ Instant Acrylic HUD Overlay</li>
            <li>✓ Directory Watchers</li>
            <li>✓ Safe Recycle Bin Delete</li>
          </ul>
        </div>

        <div class="platform-col">
          <div class="platform-icon">🍎</div>
          <div class="platform-title">macOS</div>
          <div class="platform-spec">macOS 14+ Apple Silicon/Intel</div>
          <ul class="platform-features">
            <li>✓ Menu Bar Extra (NSStatusItem)</li>
            <li>✓ Global Shortcut (Option+Space)</li>
            <li>✓ Finder Services Integration</li>
            <li>✓ Metal AI Acceleration</li>
            <li>✓ Native Apple Keychain</li>
          </ul>
        </div>

        <div class="platform-col">
          <div class="platform-icon">🤖</div>
          <div class="platform-title">Android</div>
          <div class="platform-spec">API Level 31+</div>
          <ul class="platform-features">
            <li>✓ System Share Sheet Target</li>
            <li>✓ Quick Settings Tile</li>
            <li>✓ Home Screen Widgets</li>
            <li>✓ Scoped Storage Integration</li>
            <li>✓ Zero Battery Drain in Idle</li>
          </ul>
        </div>

        <div class="platform-col">
          <div class="platform-icon">📱</div>
          <div class="platform-title">iOS</div>
          <div class="platform-spec">iOS 17+</div>
          <ul class="platform-features">
            <li>✓ Share Sheet Extension</li>
            <li>✓ Apple Shortcuts App Intents</li>
            <li>✓ Home Screen Action Widgets</li>
            <li>✓ Sandboxed Files Integration</li>
            <li>✓ Zero Background Keylogging</li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <!-- Performance Metrics -->
  <section>
    <div class="container">
      <div class="section-header">
        <div class="section-tag" data-i18n="perf_tag">MEASURED LATENCY</div>
        <h2 class="section-title" data-i18n="perf_title">Performance You Can Feel at 120 Hz</h2>
        <p class="section-subtitle" data-i18n="perf_sub">We don't claim fast—we measure it. Every component is engineered to operate inside a 16ms frame budget.</p>
      </div>

      <div class="perf-metrics-grid">
        <div class="perf-metric-card">
          <div class="metric-val">0.076ms</div>
          <div class="metric-label" data-i18n="p1_label">Average Workflow DAG Routing</div>
        </div>
        <div class="perf-metric-card">
          <div class="metric-val">&lt; 16ms</div>
          <div class="metric-label" data-i18n="p2_label">Alt+Space Overlay Invocation</div>
        </div>
        <div class="perf-metric-card">
          <div class="metric-val">2.68ms</div>
          <div class="metric-label" data-i18n="p3_label">Local AI Intent Compilation</div>
        </div>
        <div class="perf-metric-card">
          <div class="metric-val">&lt; 65MB</div>
          <div class="metric-label" data-i18n="p4_label">Idle Desktop Memory Footprint</div>
        </div>
      </div>
    </div>
  </section>

  <!-- Pricing Section -->
  <section id="pricing" style="background: var(--bg-1);">
    <div class="container">
      <div class="section-header">
        <div class="section-tag" data-i18n="pricing_tag">COMMERCIAL TRANSPARENCY</div>
        <h2 class="section-title" data-i18n="pricing_title">Fair, Anti-Subscription Fatigue Pricing</h2>
        <p class="section-subtitle" data-i18n="pricing_sub">
          No $20/month SaaS traps for a local desktop utility. Start free, explore Pro without entering a credit card, or own it permanently with a Lifetime license.
        </p>
      </div>

      <div class="pricing-grid">
        <!-- Community Core -->
        <div class="pricing-card">
          <div class="pricing-tier" data-i18n="tier_free">Community Core</div>
          <div class="pricing-price">$0</div>
          <p style="color: var(--text-2); font-size: 13px;" data-i18n="tier_free_sub">Free forever. No credit card required.</p>
          <ul class="pricing-features">
            <li><span class="check-icon">✓</span> <span data-i18n="f_free_1">All 15 Core Curated Recipes</span></li>
            <li><span class="check-icon">✓</span> <span data-i18n="f_free_2">Instant Alt+Space Command HUD</span></li>
            <li><span class="check-icon">✓</span> <span data-i18n="f_free_3">Sub-1ms deterministic execution</span></li>
            <li><span class="check-icon">✓</span> <span data-i18n="f_free_4">Local-first privacy guarantee</span></li>
            <li><span class="check-icon">✓</span> <span data-i18n="f_free_5">Standard Dark & OLED Themes</span></li>
            <li><span class="check-icon">✓</span> <span data-i18n="f_free_6">Unlimited local recipe executions</span></li>
          </ul>
          <a href="#downloads" class="btn-lg btn-secondary" style="width: 100%; text-align: center; justify-content: center;" data-i18n="btn_get_free">Download Free</a>
        </div>

        <!-- Pro Annual -->
        <div class="pricing-card">
          <div class="pricing-tier" data-i18n="tier_annual">Pro Annual</div>
          <div class="pricing-price">$39 <span data-i18n="per_year">/ year</span></div>
          <p style="color: var(--text-2); font-size: 13px;" data-i18n="tier_annual_sub">$3.25/mo billed annually. 14-day free trial.</p>
          <ul class="pricing-features">
            <li><span class="check-icon">✓</span> <span data-i18n="f_pro_1">Unlimited custom DAG workflows</span></li>
            <li><span class="check-icon">✓</span> <span data-i18n="f_pro_2">Local AI Natural Language Compiler</span></li>
            <li><span class="check-icon">✓</span> <span data-i18n="f_pro_3">Batch file pipelines (>1000 items)</span></li>
            <li><span class="check-icon">✓</span> <span data-i18n="f_pro_4">Developer Pack (JWT, JSON, cURL, RegEx)</span></li>
            <li><span class="check-icon">✓</span> <span data-i18n="f_pro_5">Unlimited encrypted local history</span></li>
            <li><span class="check-icon">✓</span> <span data-i18n="f_pro_6">Custom rice themes & accent editor</span></li>
          </ul>
          <a href="#downloads" class="btn-lg btn-secondary" style="width: 100%; text-align: center; justify-content: center;" data-i18n="btn_start_trial">Start 14-Day Free Trial</a>
        </div>

        <!-- Pro Lifetime -->
        <div class="pricing-card pro lifetime">
          <div class="pricing-tier" data-i18n="tier_lifetime">Pro Lifetime Local</div>
          <div class="pricing-price">$79 <span data-i18n="one_time">one-time</span></div>
          <p style="color: var(--text-2); font-size: 13px;" data-i18n="tier_lifetime_sub">Own your automation layer permanently.</p>
          <ul class="pricing-features">
            <li><span class="check-icon">✓</span> <strong><span data-i18n="f_life_1">All Pro Local Features Permanently</span></strong></li>
            <li><span class="check-icon">✓</span> <span data-i18n="f_life_2">Cryptographic offline license token</span></li>
            <li><span class="check-icon">✓</span> <span data-i18n="f_life_3">All 1.x and 2.x updates included</span></li>
            <li><span class="check-icon">✓</span> <span data-i18n="f_life_4">Works 100% offline without phone-home</span></li>
            <li><span class="check-icon">✓</span> <span data-i18n="f_life_5">Transferable across your personal devices</span></li>
            <li><span class="check-icon">✓</span> <span data-i18n="f_life_6">Priority community updates</span></li>
          </ul>
          <a href="#downloads" class="btn-lg btn-primary" style="width: 100%; text-align: center; justify-content: center;" data-i18n="btn_get_lifetime">Get Lifetime Pass</a>
        </div>
      </div>

      <div style="margin-top: 32px; font-size: 12px; color: var(--text-3); text-align: center; max-width: 740px; margin-left: auto; margin-right: auto; line-height: 1.6;">
        <strong data-i18n="lifetime_terms_title">Honest Lifetime Terms:</strong> <span data-i18n="lifetime_terms_body">Pro Lifetime Local provides permanent entitlement to all local software capabilities on your personal hardware. Future optional server-side sync and hosted heavy compute models (Plus Cloud at $7.99/mo) are separate subscriptions to protect company economic sustainability.</span>
      </div>
    </div>
  </section>

  <!-- Download Experience -->
  <section id="downloads">
    <div class="container">
      <div class="section-header">
        <div class="section-tag" data-i18n="dl_tag">GET OPERON</div>
        <h2 class="section-title" data-i18n="dl_title">Download for Your Devices</h2>
        <p class="section-subtitle" data-i18n="dl_sub">Clean, honest build artifacts. No bloatware, no adware, no telemetry.</p>
      </div>

      <div class="platforms-row">
        <div class="platform-col">
          <div class="platform-icon">🪟</div>
          <div class="platform-title">Windows</div>
          <div class="platform-spec">v1.0.0-rc.1 • MSIX / EXE</div>
          <p style="font-size:12px; color:var(--text-2); margin-bottom:14px;" data-i18n="win_desc">Instant installer for Windows 10 & 11 (x64).</p>
          <a href="https://github.com/RovelLabs/agy/releases/tag/v1.0.0-rc.1" class="btn-chip" style="justify-content:center; width:100%;" data-i18n="btn_dl_win">Download for Windows</a>
        </div>

        <div class="platform-col">
          <div class="platform-icon">🍎</div>
          <div class="platform-title">macOS</div>
          <div class="platform-spec">v1.0.0-rc.1 • Universal DMG</div>
          <p style="font-size:12px; color:var(--text-2); margin-bottom:14px;" data-i18n="mac_desc">Apple Silicon (M1-M4) and Intel Mac support.</p>
          <a href="https://github.com/RovelLabs/agy/releases/tag/v1.0.0-rc.1" class="btn-chip" style="justify-content:center; width:100%;" data-i18n="btn_dl_mac">Download for Mac</a>
        </div>

        <div class="platform-col">
          <div class="platform-icon">🤖</div>
          <div class="platform-title">Android</div>
          <div class="platform-spec">v1.0.0-rc.1 • APK / Play Store</div>
          <p style="font-size:12px; color:var(--text-2); margin-bottom:14px;" data-i18n="android_desc">Direct APK download and Google Play target.</p>
          <a href="https://github.com/RovelLabs/agy/releases/tag/v1.0.0-rc.1" class="btn-chip" style="justify-content:center; width:100%;" data-i18n="btn_dl_apk">Download APK</a>
        </div>

        <div class="platform-col">
          <div class="platform-icon">📱</div>
          <div class="platform-title">iOS</div>
          <div class="platform-spec">iOS 17+ • TestFlight Beta</div>
          <p style="font-size:12px; color:var(--text-2); margin-bottom:14px;" data-i18n="ios_desc">App Intents & Share Extension TestFlight build.</p>
          <a href="https://github.com/RovelLabs/agy/releases/tag/v1.0.0-rc.1" class="btn-chip" style="justify-content:center; width:100%;" data-i18n="btn_join_testflight">Join TestFlight</a>
        </div>
      </div>
    </div>
  </section>

  <!-- FAQ Section -->
  <section id="faq" style="background: var(--bg-1);">
    <div class="container">
      <div class="section-header">
        <div class="section-tag" data-i18n="faq_tag">FREQUENTLY ASKED QUESTIONS</div>
        <h2 class="section-title" data-i18n="faq_title">Everything You Need to Know</h2>
        <p class="section-subtitle" data-i18n="faq_sub">Clear, honest answers about privacy, licensing, and architecture.</p>
      </div>

      <div class="faq-list">
        <div class="faq-item">
          <div class="faq-question">
            <span data-i18n="q1">How is Operon different from Raycast or Apple Shortcuts?</span>
            <span class="faq-chevron">▼</span>
          </div>
          <div class="faq-answer" data-i18n="a1">
            Raycast is primarily macOS-focused and charges $8–$16/mo for cloud AI features. Apple Shortcuts only works inside Apple's ecosystem. Operon is a unified cross-platform layer (Windows, macOS, Android, iOS), runs 100% local-first, and executes deterministic workflows with sub-0.1ms latency without demanding cloud subscriptions.
          </div>
        </div>

        <div class="faq-item">
          <div class="faq-question">
            <span data-i18n="q2">Does Operon send my clipboard or files to any remote server?</span>
            <span class="faq-chevron">▼</span>
          </div>
          <div class="faq-answer" data-i18n="a2">
            No. Never. Operon is strictly local-first. All text transformations, image compressions, file renames, and local AI intent compilations happen 100% on your client device CPU/GPU. There is zero telemetry by default.
          </div>
        </div>

        <div class="faq-item">
          <div class="faq-question">
            <span data-i18n="q3">What does Lifetime Local mean exactly?</span>
            <span class="faq-chevron">▼</span>
          </div>
          <div class="faq-answer" data-i18n="a3">
            Lifetime Local provides permanent, perpetual entitlement to all local software features across your personal computers and mobile devices for all 1.x and 2.x releases. Your cryptographically signed license token (OPKEY-...) works completely offline forever without checking in with our servers. Future optional server sync and cloud compute services (Plus Cloud) are separate subscriptions.
          </div>
        </div>

        <div class="faq-item">
          <div class="faq-question">
            <span data-i18n="q4">Can I use Operon in Russia, CIS, or regions with card restrictions?</span>
            <span class="faq-chevron">▼</span>
          </div>
          <div class="faq-answer" data-i18n="a4">
            Yes. The Community Core is completely free with no payment method required anywhere in the world. For Pro licenses, our billing architecture supports regional payment rails (SBP, YooKassa, Telegram Stars, and crypto) without violating legal policies or international regulations.
          </div>
        </div>

        <div class="faq-item">
          <div class="faq-question">
            <span data-i18n="q5">How does the Local AI Intent Compiler work without sending data to OpenAI?</span>
            <span class="faq-chevron">▼</span>
          </div>
          <div class="faq-answer" data-i18n="a5">
            Operon uses an on-device hybrid compiler: a sub-millisecond deterministic NLP grammar engine coupled with local small language models (Gemma 2B / Qwen 1.5B). It maps your natural language requests directly to strongly typed JSON workflows on your local machine.
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer">
    <div class="container">
      <div class="footer-grid">
        <div>
          <div class="nav-brand" style="margin-bottom: 12px;">
            <svg viewBox="0 0 32 32">
              <polygon points="16,2 29,9.5 29,22.5 16,30 3,22.5 3,9.5" fill="#121518" stroke="#38BDF8" stroke-width="2.5"/>
              <circle cx="16" cy="16" r="3.5" fill="#38BDF8"/>
            </svg>
            OPERON
          </div>
          <p style="font-size: 13px; color: var(--text-2); max-width: 320px; line-height: 1.6;" data-i18n="footer_bio">
            The autonomous personal operating layer. Local-first deterministic workflows engineered for privacy, speed, and cross-platform continuity.
          </p>
        </div>

        <div>
          <div class="footer-col-title" data-i18n="footer_col_product">Product</div>
          <ul class="footer-links">
            <li><a href="#demo" data-i18n="nav_demo">Interactive HUD</a></li>
            <li><a href="#recipes" data-i18n="nav_recipes">Recipe Library</a></li>
            <li><a href="#platforms" data-i18n="nav_platforms">Platform Matrix</a></li>
            <li><a href="#pricing" data-i18n="nav_pricing">Pricing Plans</a></li>
            <li><a href="#downloads" data-i18n="nav_get">Downloads</a></li>
          </ul>
        </div>

        <div>
          <div class="footer-col-title" data-i18n="footer_col_dev">Developers</div>
          <ul class="footer-links">
            <li><a href="https://github.com/RovelLabs/agy" target="_blank">GitHub Repository</a></li>
            <li><a href="https://github.com/RovelLabs/agy/releases/tag/v1.0.0-rc.1" target="_blank">Release Notes (v1.0.0-rc.1)</a></li>
            <li><a href="#faq" data-i18n="nav_faq">Architecture FAQ</a></li>
            <li><a href="https://github.com/RovelLabs/agy/blob/master/CHANGELOG.md" target="_blank">Changelog</a></li>
          </ul>
        </div>

        <div>
          <div class="footer-col-title" data-i18n="footer_col_trust">Trust & Legal</div>
          <ul class="footer-links">
            <li><a href="#privacy" onclick="alert('Privacy Guarantee: Zero Telemetry by Default. Local processing only.')">Privacy Guarantee</a></li>
            <li><a href="#security" onclick="alert('Security Model: Capability tokens, DPAPI/Keychain secret storage, no arbitrary shell execution.')">Security Model</a></li>
            <li><a href="#terms" onclick="alert('Terms: Commercial closed-source software with perpetual local license options.')">Terms of Service</a></li>
            <li><a href="mailto:support@operon.dev">Contact Support</a></li>
          </ul>
        </div>
      </div>

      <div class="footer-bottom">
        <div>© 2026 Rovel Labs. All rights reserved. • OPERON Commercial Software</div>
        <div style="font-family: var(--font-mono);">v1.0.0-rc.1 • Built with Apple-Grade Polish & Linux Rice Personality</div>
      </div>
    </div>
  </footer>

  <!-- CLIENT SCRIPTS: LOCALIZATION, THEMES & INTERACTIVE PLAYGROUND -->
  <script>
    // I18N DICTIONARY (ENGLISH & RUSSIAN)
    const i18n = {
      en: {
        nav_demo: "Interactive HUD",
        nav_diff: "Before vs After",
        nav_recipes: "15 Recipes",
        nav_platforms: "Platforms",
        nav_pricing: "Pricing",
        nav_faq: "FAQ",
        nav_get: "Get Operon",
        hero_badge: "RELEASE CANDIDATE 1.0 • SUB-1MS DETERMINISTIC CORE",
        hero_title: "The Autonomous Personal Operating Layer",
        hero_sub: "Eliminate repetitive digital work across text, files, clipboard, and apps. Sub-millisecond keyboard HUD on desktop, fluid Share Sheet routines on mobile. 100% local-first. Zero mandatory cloud accounts.",
        hero_btn_download: "Download Free for Desktop & Mobile",
        hero_btn_demo: "Try Interactive HUD Simulation",
        preset_clean_url: "Clean Tracking URL",
        preset_format_json: "Format & Indent JSON",
        preset_tsv_md: "CSV/TSV to Markdown Table",
        preset_rename_files: "Batch Rename 50 Files",
        preset_ai_intent: "✨ Local AI Intent Compiler",
        exec_input_label: "Raw Input Data",
        exec_output_label: "Deterministic Output",
        engine_mode: "Engine Mode:",
        memory_impact: "RAM Impact:",
        privacy_status: "Privacy:",
        diff_tag: "REAL TIME SAVINGS",
        diff_title: "Normally 12 clicks. Now 1 keystroke.",
        diff_sub: "Operon bridges the gap between intention and execution across your operating system.",
        diff_badge_old: "THE OLD WAY",
        diff_badge_operon: "WITH OPERON",
        diff_1_title: "Batch Renaming & Compressing 50 PNG Screenshots",
        diff_1_desc: "Opening Photoshop or online converters, waiting for uploads, manually typing dates, and moving files one by one.",
        diff_2_title: "Stripping Tracking Spying from Shared Links",
        diff_2_desc: "Carefully highlighting and deleting utm_source, fbclid, and gclid tokens from messy links before sharing in chat.",
        diff_3_title: "Pasting Spreadsheet Data to Markdown",
        diff_3_desc: "Copying Excel or Google Sheets into GitHub or Notion results in unaligned tabs and broken text lines.",
        diff_4_title: "Inspecting JWT Tokens & Formatting API JSON",
        diff_4_desc: "Pasting proprietary API payloads and authentication tokens into third-party online tools exposes private credentials.",
        recipes_tag: "BUILT-IN PRODUCTION LIBRARY",
        recipes_title: "15 Curated Recipes Ready on Day One",
        recipes_sub: "No empty placeholders. Every single recipe is fully tested, typed, and executes instantly.",
        platforms_tag: "HONEST ARCHITECTURE",
        platforms_title: "Engineered Natively for Each OS",
        platforms_sub: "We respect platform capabilities and security sandboxes. No fake background daemons where OS policies forbid it.",
        perf_tag: "MEASURED LATENCY",
        perf_title: "Performance You Can Feel at 120 Hz",
        perf_sub: "We don't claim fast—we measure it. Every component is engineered to operate inside a 16ms frame budget.",
        p1_label: "Average Workflow DAG Routing",
        p2_label: "Alt+Space Overlay Invocation",
        p3_label: "Local AI Intent Compilation",
        p4_label: "Idle Desktop Memory Footprint",
        pricing_tag: "COMMERCIAL TRANSPARENCY",
        pricing_title: "Fair, Anti-Subscription Fatigue Pricing",
        pricing_sub: "No $20/month SaaS traps for a local desktop utility. Start free, explore Pro without entering a credit card, or own it permanently with a Lifetime license.",
        tier_free: "Community Core",
        tier_free_sub: "Free forever. No credit card required.",
        f_free_1: "All 15 Core Curated Recipes",
        f_free_2: "Instant Alt+Space Command HUD",
        f_free_3: "Sub-1ms deterministic execution",
        f_free_4: "Local-first privacy guarantee",
        f_free_5: "Standard Dark & OLED Themes",
        f_free_6: "Unlimited local recipe executions",
        btn_get_free: "Download Free",
        tier_annual: "Pro Annual",
        per_year: "/ year",
        tier_annual_sub: "$3.25/mo billed annually. 14-day free trial.",
        f_pro_1: "Unlimited custom DAG workflows",
        f_pro_2: "Local AI Natural Language Compiler",
        f_pro_3: "Batch file pipelines (>1000 items)",
        f_pro_4: "Developer Pack (JWT, JSON, cURL, RegEx)",
        f_pro_5: "Unlimited encrypted local history",
        f_pro_6: "Custom rice themes & accent editor",
        btn_start_trial: "Start 14-Day Free Trial",
        tier_lifetime: "Pro Lifetime Local",
        one_time: "one-time",
        tier_lifetime_sub: "Own your automation layer permanently.",
        f_life_1: "All Pro Local Features Permanently",
        f_life_2: "Cryptographic offline license token",
        f_life_3: "All 1.x and 2.x updates included",
        f_life_4: "Works 100% offline without phone-home",
        f_life_5: "Transferable across your personal devices",
        f_life_6: "Priority community updates",
        btn_get_lifetime: "Get Lifetime Pass",
        lifetime_terms_title: "Honest Lifetime Terms:",
        lifetime_terms_body: "Pro Lifetime Local provides permanent entitlement to all local software capabilities on your personal hardware. Future optional server-side sync and hosted heavy compute models (Plus Cloud at $7.99/mo) are separate subscriptions to protect company economic sustainability.",
        dl_tag: "GET OPERON",
        dl_title: "Download for Your Devices",
        dl_sub: "Clean, honest build artifacts. No bloatware, no adware, no telemetry.",
        win_desc: "Instant installer for Windows 10 & 11 (x64).",
        btn_dl_win: "Download for Windows",
        mac_desc: "Apple Silicon (M1-M4) and Intel Mac support.",
        btn_dl_mac: "Download for Mac",
        android_desc: "Direct APK download and Google Play target.",
        btn_dl_apk: "Download APK",
        ios_desc: "App Intents & Share Extension TestFlight build.",
        btn_join_testflight: "Join TestFlight",
        faq_tag: "FREQUENTLY ASKED QUESTIONS",
        faq_title: "Everything You Need to Know",
        faq_sub: "Clear, honest answers about privacy, licensing, and architecture.",
        q1: "How is Operon different from Raycast or Apple Shortcuts?",
        a1: "Raycast is primarily macOS-focused and charges $8–$16/mo for cloud AI features. Apple Shortcuts only works inside Apple's ecosystem. Operon is a unified cross-platform layer (Windows, macOS, Android, iOS), runs 100% local-first, and executes deterministic workflows with sub-0.1ms latency without demanding cloud subscriptions.",
        q2: "Does Operon send my clipboard or files to any remote server?",
        a2: "No. Never. Operon is strictly local-first. All text transformations, image compressions, file renames, and local AI intent compilations happen 100% on your client device CPU/GPU. There is zero telemetry by default.",
        q3: "What does Lifetime Local mean exactly?",
        a3: "Lifetime Local provides permanent, perpetual entitlement to all local software features across your personal computers and mobile devices for all 1.x and 2.x releases. Your cryptographically signed license token (OPKEY-...) works completely offline forever without checking in with our servers. Future optional server sync and cloud compute services (Plus Cloud) are separate subscriptions.",
        q4: "Can I use Operon in Russia, CIS, or regions with card restrictions?",
        a4: "Yes. The Community Core is completely free with no payment method required anywhere in the world. For Pro licenses, our billing architecture supports regional payment rails (SBP, YooKassa, Telegram Stars, and crypto) without violating legal policies or international regulations.",
        q5: "How does the Local AI Intent Compiler work without sending data to OpenAI?",
        a5: "Operon uses an on-device hybrid compiler: a sub-millisecond deterministic NLP grammar engine coupled with local small language models (Gemma 2B / Qwen 1.5B). It maps your natural language requests directly to strongly typed JSON workflows on your local machine."
      },

      ru: {
        nav_demo: "Интерактивный HUD",
        nav_diff: "До и после",
        nav_recipes: "15 Рецептов",
        nav_platforms: "Платформы",
        nav_pricing: "Тарифы",
        nav_faq: "Вопросы и ответы",
        nav_get: "Скачать",
        hero_badge: "РЕЛИЗ-КАНДИДАТ 1.0 • ДЕТЕРМИНИРОВАННОЕ ЯДРО СУБ-1МС",
        hero_title: "Автономный операционный слой для ваших устройств",
        hero_sub: "Устраните рутинную цифровую работу с текстом, файлами, буфером обмена и приложениями. Мгновенный HUD по Alt+Space на ПК, удобные действия Share Sheet на смартфонах. 100% локально. Без обязательных облачных аккаунтов.",
        hero_btn_download: "Скачать бесплатно для ПК и смартфонов",
        hero_btn_demo: "Попробовать интерактивный HUD",
        preset_clean_url: "Очистка трекинга ссылок",
        preset_format_json: "Форматирование JSON",
        preset_tsv_md: "Таблицы CSV/TSV в Markdown",
        preset_rename_files: "Пакетное переименование 50 файлов",
        preset_ai_intent: "✨ Локальный AI-компилятор намерений",
        exec_input_label: "Входные данные",
        exec_output_label: "Результат выполнения",
        engine_mode: "Режим ядра:",
        memory_impact: "Память:",
        privacy_status: "Приватность:",
        diff_tag: "РЕАЛЬНАЯ ЭКОНОМИЯ ВРЕМЕНИ",
        diff_title: "Обычно 12 кликов. Теперь одно нажатие клавиши.",
        diff_sub: "Operon соединяет намерение пользователя и исполнение в операционной системе.",
        diff_badge_old: "СТАРЫЙ СПОСОБ",
        diff_badge_operon: "С OPERON",
        diff_1_title: "Пакетное сжатие и переименование 50 скриншотов",
        diff_1_desc: "Открытие графического редактора или онлайн-конвертера, ожидание загрузки, ручной ввод дат и сохранение файлов по очереди.",
        diff_2_title: "Очистка слежки и UTM-меток из ссылок",
        diff_2_desc: "Тщательное выделение и удаление хвостов utm_source, fbclid и gclid из длинных ссылок перед отправкой в чат.",
        diff_3_title: "Вставка данных таблиц в чистый Markdown",
        diff_3_desc: "Копирование из Excel или Google Таблиц в GitHub или Notion приводит к сбитым отступам и ломаным строкам.",
        diff_4_title: "Анализ JWT-токенов и JSON без утечек",
        diff_4_desc: "Вставка корпоративных API-токенов в сторонние веб-сайты создает прямую угрозу безопасности.",
        recipes_tag: "ВСТРОЕННАЯ БИБЛИОТЕКА",
        recipes_title: "15 готовых рецептов прямо из коробки",
        recipes_sub: "Никаких пустых заглушек. Каждый рецепт протестирован, типизирован и исполняется мгновенно.",
        platforms_tag: "ЧЕСТНАЯ АРХИТЕКТУРА",
        platforms_title: "Нативная интеграция под каждую ОС",
        platforms_sub: "Мы уважаем политики безопасности операционных систем. Никаких фейковых фоновых процессов там, где это запрещено ОС.",
        perf_tag: "ИЗМЕРЕННАЯ СКОРОСТЬ",
        perf_title: "Плавность, которую вы чувствуете на 120 Гц",
        perf_sub: "Мы не просто заявляем о скорости — мы измеряем её. Каждый компонент работает в рамках 16-миллисекундного кадра.",
        p1_label: "Средняя задержка роутинга DAG",
        p2_label: "Вызов HUD по Alt+Space",
        p3_label: "Локальная компиляция намерений AI",
        p4_label: "Память в фоне на ПК",
        pricing_tag: "ПРОЗРАЧНАЯ КОММЕРЦИЯ",
        pricing_title: "Честные тарифы без подписочной усталости",
        pricing_sub: "Никаких ловушек с подпиской $20/мес за локальную утилиту. Пользуйтесь базовой версией бесплатно, тестируйте Pro без привязки карты или купите бессрочную лицензию.",
        tier_free: "Community Core",
        tier_free_sub: "Бесплатно навсегда. Без банковской карты.",
        f_free_1: "Все 15 базовых рецептов",
        f_free_2: "Мгновенный HUD по Alt+Space",
        f_free_3: "Суб-миллисекундное исполнение",
        f_free_4: "Гарантия локальной приватности",
        f_free_5: "Темы Graphite и OLED Black",
        f_free_6: "Неограниченное число запусков",
        btn_get_free: "Скачать бесплатно",
        tier_annual: "Pro Annual",
        per_year: "/ год",
        tier_annual_sub: "39$/год (~3.25$/мес). 14 дней триала без карты.",
        f_pro_1: "Неограниченные кастомные цепочки DAG",
        f_pro_2: "Локальный компилятор на естественном языке",
        f_pro_3: "Пакетная обработка файлов (>1000 шт.)",
        f_pro_4: "Набор разработчика (JWT, JSON, cURL, RegEx)",
        f_pro_5: "Зашифрованная локальная история",
        f_pro_6: "Кастомные rice-темы и редактор акцентов",
        btn_start_trial: "Активировать триал на 14 дней",
        tier_lifetime: "Pro Lifetime Local",
        one_time: "разово",
        tier_lifetime_sub: "Собственный инструмент автоматизации навсегда.",
        f_life_1: "Все локальные Pro-функции навсегда",
        f_life_2: "Криптографический оффлайн-токен лицензии",
        f_life_3: "Все обновления 1.x и 2.x включены",
        f_life_4: "Работает 100% оффлайн без запросов к серверу",
        f_life_5: "Переносится между вашими устройствами",
        f_life_6: "Приоритетные обновления сообщества",
        btn_get_lifetime: "Купить вечную лицензию",
        lifetime_terms_title: "Честные условия бессрочной лицензии:",
        lifetime_terms_body: "Pro Lifetime Local предоставляет бессрочное право на все локальные возможности приложения на вашем оборудовании. Будущие серверные сервисы синхронизации и облачных вычислений (Plus Cloud за $7.99/мес) являются отдельными подписками ради финансовой устойчивости проекта.",
        dl_tag: "УСТАНОВКА OPERON",
        dl_title: "Скачать для ваших устройств",
        dl_sub: "Чистые проверенные сборки. Без рекламного ПО, без слежки, без мусора.",
        win_desc: "Установщик для Windows 10 и 11 (x64).",
        btn_dl_win: "Скачать для Windows",
        mac_desc: "Поддержка Apple Silicon (M1-M4) и Intel Mac.",
        btn_dl_mac: "Скачать для macOS",
        android_desc: "Прямой APK-файл и сборка для Google Play.",
        btn_dl_apk: "Скачать APK",
        ios_desc: "Сборка TestFlight с поддержкой Команд Apple.",
        btn_join_testflight: "Войти в TestFlight",
        faq_tag: "ЧАСТО ЗАДАВАЕМЫЕ ВОПРОСЫ",
        faq_title: "Ответы на главные вопросы",
        faq_sub: "Всё о приватности, лицензировании и архитектуре.",
        q1: "Чем Operon отличается от Raycast или Apple Shortcuts?",
        a1: "Raycast ориентирован преимущественно на Mac и требует ежемесячной платы $8–$16 за функции ИИ. Команды Apple работают только в экосистеме Apple. Operon — это единый кроссплатформенный слой (Windows, macOS, Android, iOS), работающий на 100% локально и детерминированно с задержкой менее 0.1 мс.",
        q2: "Отправляет ли Operon мой буфер обмена или файлы в интернет?",
        a2: "Нет. Никогда. Все преобразования текста, сжатие изображений и парсинг происходят исключительно на вашем процессоре и видеокарте. Телеметрия по умолчанию отключена.",
        q3: "Что означает бессрочная лицензия Lifetime Local?",
        a3: "Она даёт пожизненное право на все локальные возможности приложения версий 1.x и 2.x. Ваш криптографический ключ (OPKEY-...) проверяется оффлайн и работает без подключения к серверам.",
        q4: "Работает ли оплата в России и СНГ?",
        a4: "Да. Базовая версия бесплатна для всех. Для Pro-лицензий поддерживаются доступные региональные способы оплаты (СБП, ЮKassa, Telegram Stars и криптовалюта) без нарушения законодательства.",
        q5: "Как работает локальный AI без отправки данных в OpenAI?",
        a5: "Operon использует гибридный оффлайн-компилятор: грамматический парсер и компактные квантованные модели на устройстве, транслируя ваш текст в строгий JSON-граф без облака."
      }
    };

    // LANGUAGE CONTROLLER
    let currentLang = 'en';
    function setLanguage(lang) {
      currentLang = lang;
      document.documentElement.setAttribute('data-lang', lang);
      document.getElementById('currentLangLabel').textContent = lang.toUpperCase();

      const dict = i18n[lang] || i18n.en;
      document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (dict[key]) {
          el.innerHTML = dict[key];
        }
      });
    }

    document.getElementById('langSwitchBtn').addEventListener('click', () => {
      setLanguage(currentLang === 'en' ? 'ru' : 'en');
    });

    // THEME CONTROLLER
    const themes = ['graphite', 'midnight', 'oled', 'lunar'];
    let themeIndex = 0;
    function cycleTheme() {
      themeIndex = (themeIndex + 1) % themes.length;
      const theme = themes[themeIndex];
      document.documentElement.setAttribute('data-theme', theme);
      document.getElementById('currentThemeLabel').textContent = theme.charAt(0).toUpperCase() + theme.slice(1);
    }
    document.getElementById('themeSwitchBtn').addEventListener('click', cycleTheme);

    // FAQ ACCORDION
    document.querySelectorAll('.faq-item').forEach(item => {
      item.querySelector('.faq-question').addEventListener('click', () => {
        item.classList.toggle('open');
      });
    });

    // INTERACTIVE HUD SIMULATION
    const hudPresets = {
      clean_url: {
        input: "https://shop.example.com/item?id=8841&utm_source=twitter&utm_medium=cpc&utm_campaign=summer_promo&fbclid=IwAR0491823&igshid=op_test",
        output: "✓ Clean URL (Stripped 5 tracking parameters in 0.04ms):\n\nhttps://shop.example.com/item?id=8841",
        speed: "0.04 ms",
        size: "148 B"
      },
      format_json: {
        input: '{"service":"operon","version":"1.0.0","capabilities":["dag_engine","offline_ai","sub_ms_latency"],"active":true}',
        output: '✓ Formatted & Validated JSON (2-space indent in 0.08ms):\n\n{\n  "service": "operon",\n  "version": "1.0.0",\n  "capabilities": [\n    "dag_engine",\n    "offline_ai",\n    "sub_ms_latency"\n  ],\n  "active": true\n}',
        speed: "0.08 ms",
        size: "115 B"
      },
      tsv_md: {
        input: "ID\tAction\tDomain\tLatency\n1\tClean URL\tText\t0.04ms\n2\tFormat JSON\tDev\t0.08ms\n3\tWebP Convert\tImage\tNative",
        output: "| ID | Action | Domain | Latency |\n| --- | --- | --- | --- |\n| 1 | Clean URL | Text | 0.04ms |\n| 2 | Format JSON | Dev | 0.08ms |\n| 3 | WebP Convert | Image | Native |",
        speed: "0.12 ms",
        size: "96 B"
      },
      rename_files: {
        input: "[50 files selected in Downloads]\nScreenshot_2026-09-13_14-22-01.png\nScreenshot_2026-09-13_14-22-34.png\n... (+48 items)",
        output: "✓ Batch Renamed 50 Files ({date}_{counter}_{name}.ext in 0.32ms):\n\n20260913_001_Screenshot.webp (Space saved: 82%)\n20260913_002_Screenshot.webp (Space saved: 84%)\n... (+48 files safely converted)",
        speed: "0.32 ms",
        size: "50 files"
      },
      ai_intent: {
        input: 'User Intent: "When I copy an image link, download it, convert to WebP, and copy markdown embed tag"',
        output: "✓ Local AI Intent Compiler (Tier 1 Grammatical AST assembled in 2.68ms):\\n\\nPlan Synthesized:\\n1. clipboard.read (Link detected)\\n2. image.convert_format (format: 'webp', quality: 85)\\n3. text.template ('![image](step2.path)')\\n4. clipboard.write (Markdown ready)\\n\\n[Human Preview Approved • Stored Deterministically]",
        speed: "2.68 ms",
        size: "Prompt"
      }
    };

    function setPreset(key) {
      document.querySelectorAll('.hud-preset-chip').forEach(c => c.classList.remove('active'));
      const activeBtn = Array.from(document.querySelectorAll('.hud-preset-chip')).find(b => b.getAttribute('onclick').includes(key));
      if (activeBtn) activeBtn.classList.add('active');

      const data = hudPresets[key];
      if (data) {
        document.getElementById('execInputBox').textContent = data.input;
        document.getElementById('execOutputBox').textContent = data.output;
        document.getElementById('inputSizeBadge').textContent = data.size;
        document.getElementById('outputSpeedBadge').textContent = data.speed;
        document.getElementById('interactiveHudInput').value = key.replace('_', ' ');
      }
    }

    // Default HUD state
    setPreset('clean_url');
  </script>
</body>
</html>`;
}
