@echo off
setlocal
cd /d "%~dp0"
start "" /b powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0apps\desktop\src\windows\win_tray.ps1"
start "" node "%~dp0apps\desktop\src\main.js"
