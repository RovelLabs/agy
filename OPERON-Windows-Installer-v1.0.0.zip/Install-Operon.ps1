# OPERON Windows Automated Installer
param(
    [switch]$Quiet = $false
)

$targetDir = "$env:LOCALAPPDATA\Operon"
$currentDir = $PSScriptRoot

Write-Host "Installing OPERON into $targetDir..." -ForegroundColor Cyan

# Stop existing processes if running
Get-Process -Name node, powershell -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "*Operon*" } | Stop-Process -Force -ErrorAction SilentlyContinue

# Ensure directory exists
if (-not (Test-Path $targetDir)) {
    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
}

# Copy files
Copy-Item -Path "$currentDir\*" -Destination $targetDir -Recurse -Force

# Create Desktop Shortcut
$wsh = New-Object -ComObject WScript.Shell
$desktopShortcut = $wsh.CreateShortcut("$env:USERPROFILE\Desktop\OPERON.lnk")
$desktopShortcut.TargetPath = "$targetDir\operon.cmd"
$desktopShortcut.WorkingDirectory = $targetDir
$desktopShortcut.Description = "OPERON - The Autonomous Personal Operating Layer"
$desktopShortcut.Save()

# Create Start Menu Shortcut
$startMenuDir = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs"
$startShortcut = $wsh.CreateShortcut("$startMenuDir\Operon.lnk")
$startShortcut.TargetPath = "$targetDir\operon.cmd"
$startShortcut.WorkingDirectory = $targetDir
$startShortcut.Description = "OPERON Automation"
$startShortcut.Save()

# Register in Windows Add/Remove Programs (Registry)
$regKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Operon"
if (-not (Test-Path $regKey)) {
    New-Item -Path $regKey -Force | Out-Null
}
Set-ItemProperty -Path $regKey -Name "DisplayName" -Value "OPERON (Autonomous Operating Layer)"
Set-ItemProperty -Path $regKey -Name "DisplayVersion" -Value "1.0.0-rc.1"
Set-ItemProperty -Path $regKey -Name "Publisher" -Value "OPERON Systems"
Set-ItemProperty -Path $regKey -Name "InstallLocation" -Value $targetDir
Set-ItemProperty -Path $regKey -Name "UninstallString" -Value "powershell.exe -ExecutionPolicy Bypass -File `"$targetDir\Uninstall-Operon.ps1`""
Set-ItemProperty -Path $regKey -Name "QuietUninstallString" -Value "powershell.exe -ExecutionPolicy Bypass -File `"$targetDir\Uninstall-Operon.ps1`" -Quiet"

Write-Host "[OK] OPERON Installation Complete!" -ForegroundColor Green
if (-not $Quiet) {
    Write-Host "Launch OPERON from your Desktop or Start Menu, or press Alt+Space anytime." -ForegroundColor Yellow
}
