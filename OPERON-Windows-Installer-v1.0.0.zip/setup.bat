@echo off
cd /d "%~dp0"
echo ===================================================
echo   Installing OPERON (Autonomous Personal OS Layer)
echo ===================================================
powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0Install-Operon.ps1"
pause
