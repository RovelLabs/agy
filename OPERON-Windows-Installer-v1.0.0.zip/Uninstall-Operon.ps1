# OPERON Windows Automated Uninstaller
param(
    [switch]$Quiet = $false
)

Write-Host "Uninstalling OPERON..." -ForegroundColor Yellow

# Terminate running instances
Get-Process -Name node, powershell -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "*Operon*" } | Stop-Process -Force -ErrorAction SilentlyContinue

# Remove Desktop & Start Menu shortcuts
Remove-Item -Path "$env:USERPROFILE\Desktop\OPERON.lnk" -Force -ErrorAction SilentlyContinue
Remove-Item -Path "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Operon.lnk" -Force -ErrorAction SilentlyContinue

# Remove Registry uninstall entry
Remove-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Operon" -Recurse -Force -ErrorAction SilentlyContinue

# Remove Startup run entry if exists
Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" -Name "Operon" -ErrorAction SilentlyContinue

# Clean target directory
$targetDir = "$env:LOCALAPPDATA\Operon"
if (Test-Path $targetDir) {
    Remove-Item -Path $targetDir -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host "[OK] OPERON Uninstalled successfully." -ForegroundColor Green
